# SDK

Schema-first SDK for defining, composing, and deploying Astrale Domains. The public authoring
surface covers Domain handlers, provider-neutral Capabilities, Workflows, Query, Mutation, State,
and deployment adapters without coupling business code to one host runtime.

[![CI](https://github.com/astrale-os/sdk/actions/workflows/ci.yml/badge.svg)](https://github.com/astrale-os/sdk/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)

## Install

```bash
npm install @astrale-os/sdk
```

## Development

### Prerequisites

- Node.js 24.18.0
- pnpm 11.13.1

### Setup

The SDK is consumed as a submodule of the main Astrale workspace:

```bash
git clone --recursive https://github.com/astrale-os/workspace.git
cd workspace
pnpm install
```

### Commands

```bash
pnpm typecheck      # Type check
pnpm test           # Run tests
pnpm lint           # Lint
pnpm format         # Format
```

## License

Apache License 2.0 — see [LICENSE](LICENSE) for details.
