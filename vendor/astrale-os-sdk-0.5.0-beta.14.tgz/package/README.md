# SDK

Schema-first SDK for defining, composing, and deploying Astrale Domains. The public authoring
surface covers Domain handlers, provider-neutral Capabilities, Workflows, Query, Mutation, State,
and deployment adapters without coupling business code to one host runtime.

[![CI](https://github.com/astrale-os/sdk/actions/workflows/ci.yml/badge.svg)](https://github.com/astrale-os/sdk/actions/workflows/ci.yml)
[![License: Apache-2.0](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)

## Install

Configure the Astrale scope for GitHub Packages and provide a token with `read:packages`; the SDK's
Kernel dependencies are intentionally distributed there:

```ini
# ~/.npmrc
registry=https://registry.npmjs.org/
@astrale-os:registry=https://npm.pkg.github.com/
//npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
```

```bash
export NODE_AUTH_TOKEN="$(gh auth token)"
npm install @astrale-os/sdk
```

During the beta program, opt in explicitly:

```bash
npm install @astrale-os/sdk@beta
npx -y create-astrale-domain@beta my-domain --yes
```

See [the release lifecycle](docs/release.md) for package-cohort versioning, verification, and stable
promotion.

## Development

### Prerequisites

- Node.js 26.7.0 (default) or Node.js 24; published packages remain compatible with Node.js 22+
- pnpm 11.13.1

### Setup

The SDK is consumed as a submodule of the main Astrale workspace:

```bash
git clone --recursive https://github.com/astrale-os/workspace.git
cd workspace
pnpm install
```

### Commands

```bash
pnpm typecheck      # Type check
pnpm test           # Run tests
pnpm lint           # Lint
pnpm format         # Format
pnpm check:knowledge # Validate the canonical Domain authoring knowledge
pnpm check:issues    # Validate structured cross-repository issues
```

The structured [Domain authoring knowledge](knowledge/README.md) is the source for contributor
guidance and the generated linter policy.

### Domain lint layout overrides

`astrale-domain lint` defaults to the canonical layer roots and aliases, including `functions/`,
`#functions`, and `#functions/*`. A Domain that uses different physical vocabulary can remap a
semantic layer in `astrale.lint.json` without changing the rules attached to that layer:

```json
{
  "layers": {
    "functions": {
      "sourcePath": "actions/",
      "alias": "#actions"
    }
  }
}
```

The linter then expects `actions/`, `#actions`, and `#actions/*` in the source tree,
`compilerOptions.paths`, and `package.json#imports`. Omit the file to keep the canonical defaults.

Structured review [issues](issues/README.md) retain observation-first evidence and later governance
attachments without becoming current contract authority.

## License

Apache License 2.0 — see [LICENSE](LICENSE) for details.
